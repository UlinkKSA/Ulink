<?php
error_reporting(E_ERROR);
$servername="localhost";
$dusername="root";
$dpassword="";
$dbname="user";
// Establishing Connection with Server by passing server_name, user_id and password as a parameter
$connection=mysqli_connect($servername,$dusername,$dpassword,$dbname);
session_start();// Starting Session
// Storing Session
$user_check=$_SESSION['login_user'];
?>